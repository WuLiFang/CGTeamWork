# -*- coding=UTF-8 -*-
"""Database on cgtw server.  """

from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

from .database import Database

__all__ = ['Database']
